import { Request, Response } from 'express';
import Order from '../models/orderModel.js';

export const saveOrder = async (req: Request, res: Response) => {
    try {
        const { name, email, phone, address, city, pincode, amount, orderId, paymentId } = req.body;

        const order = new Order({
            name,
            email,
            phone,
            address,
            city,
            pincode,
            amount,
            razorpay_order_id: orderId,
            razorpay_payment_id: paymentId,
            status: paymentId ? 'paid' : 'pending' // if paymentId exists, assume paid (verify should ideally be called before this)
        });

        const createdOrder = await order.save();
        res.status(201).json(createdOrder);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Failed to save order" });
    }
};

export const getOrders = async (req: Request, res: Response) => {
    try {
        const orders = await Order.find({}).sort({ createdAt: -1 });
        res.json(orders);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Failed to fetch orders" });
    }
};
