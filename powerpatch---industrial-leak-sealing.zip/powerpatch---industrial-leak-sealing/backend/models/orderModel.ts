import mongoose from 'mongoose';

const orderSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true },
    phone: { type: String, required: true },
    address: { type: String, required: true },
    city: { type: String, required: true },
    pincode: { type: String, required: true },
    amount: { type: Number, required: true },
    status: { type: String, enum: ['pending', 'paid'], default: 'pending' },
    razorpay_order_id: { type: String },
    razorpay_payment_id: { type: String },
}, {
    timestamps: true
});

const Order = mongoose.model('Order', orderSchema);

export default Order;
