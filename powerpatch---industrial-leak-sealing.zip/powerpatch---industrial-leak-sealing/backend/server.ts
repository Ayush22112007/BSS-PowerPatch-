import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import cors from 'cors';
import connectDB from './backend/config/db.js';
import paymentRoutes from './backend/routes/paymentRoutes.js';
import orderRoutes from './backend/routes/orderRoutes.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
    const app = express();
    const PORT = process.env.PORT || 3000;

    // Connect to Database
    if (process.env.MONGO_URI) {
        await connectDB();
    } else {
        console.warn('MONGO_URI not found in environment variables. Database features will be disabled.');
    }

    // Middleware
    app.use(cors());
    app.use(express.json());

    // API Routes
    app.use('/api/payment', paymentRoutes);
    app.use('/api/order', orderRoutes);

    app.get('/api/health', (req, res) => {
        res.json({ status: 'ok' });
    });

    // Integrated Vite Middleware
    if (process.env.NODE_ENV !== 'production') {
        const vite = await createViteServer({
            server: { middlewareMode: true },
            appType: 'spa',
        });
        app.use(vite.middlewares);
    } else {
        const distPath = path.join(__dirname, 'dist');
        app.use(express.static(distPath));
        app.get('*', (req, res) => {
            res.sendFile(path.join(distPath, 'index.html'));
        });
    }

    app.listen(Number(PORT), '0.0.0.0', () => {
        console.log(`Server running on http://localhost:${PORT}`);
    });
}

startServer();
