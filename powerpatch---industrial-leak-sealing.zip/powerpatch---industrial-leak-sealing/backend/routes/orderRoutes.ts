import express from 'express';
import { saveOrder, getOrders } from '../controllers/orderController.js';

const router = express.Router();

router.post('/', saveOrder);
router.get('/', getOrders);

export default router;
